#ifndef Scheme_h
#define Scheme_h

#include <vector>
#include <string>

using namespace std;

class Scheme : public vector<string> {
public:
    
    Scheme();
    ~Scheme();
    
private:
    
    
};

#endif /* Scheme_h */
