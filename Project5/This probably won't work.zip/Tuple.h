/*
 * Tuple.h
 *
 *  Created on: October 24, 2021
 *      Author: Jaren Petersen
 */

#ifndef Tuple_h
#define Tuple_h

#include <stdio.h>
#include <vector>
#include <string>

using namespace std;

class Tuple : public vector<string> {
public:
    Tuple();
    ~Tuple();
private:
    
};

#endif /* Tuple_h */
