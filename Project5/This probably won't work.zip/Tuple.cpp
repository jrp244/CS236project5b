/*
 * Tuple.cpp
 *
 *  Created on: October 24, 2021
 *      Author: Jaren Petersen
 * Do I even need this file?
 */

#include "Tuple.h"

Tuple :: Tuple() {
    
}

Tuple :: ~Tuple() {
    
}


